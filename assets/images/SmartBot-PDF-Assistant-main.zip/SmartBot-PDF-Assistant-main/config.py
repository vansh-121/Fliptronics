# Ensure these are not present if not needed
STATIC_DIRECTORY = None
STATIC_ROUTE = None